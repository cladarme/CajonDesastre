package com.pgrsoft.cajondesastre.ejercicios2;

public class ConversorMedidas {
	
	public double getFarenheitFromCelsius(double celsius) {
		double resultado = (celsius * 9/5) + 32;
		return resultado;
	}
	
	public double getCelsiusFromFarenheit(double farenheit) {
		return (farenheit - 32)/ 1.8;
	}
	
	public double getMilesFromKilometers(double kilometers) {
		return kilometers * 0.621371;
	}
	
	public double getKilometersFromMiles(double miles) {
		return miles / 0.621371;
	}
	
}
