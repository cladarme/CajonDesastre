package com.pgrsoft.cajondesastre.ejercicios2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ConversorMedidasTest {

	private ConversorMedidas conversorMedidas = new ConversorMedidas();
	
	
	@Test
	void test() {
		
		double resultado1 = conversorMedidas.getCelsiusFromFarenheit(50.0);
		assertEquals(10.0, resultado1);
		
	}

}
