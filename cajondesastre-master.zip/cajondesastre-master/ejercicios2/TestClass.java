package com.pgrsoft.cajondesastre.ejercicios2;

public class TestClass {

	public static void main(String[] args) {
		
		ConversorMedidas conversorMedidas = new ConversorMedidas();
		
		double resultado = conversorMedidas.getFarenheitFromCelsius(10);
		System.out.println(resultado);
		
		double resultado2 = conversorMedidas.getCelsiusFromFarenheit(50);
		System.out.println(resultado2);
		
		double resultado3 = conversorMedidas.getMilesFromKilometers(1);
		System.out.println(resultado3);
		
		double resultado4 = conversorMedidas.getKilometersFromMiles(1);
		System.out.println(resultado4);
		
	}

}
