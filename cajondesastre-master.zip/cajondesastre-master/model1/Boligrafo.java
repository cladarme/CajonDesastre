package com.pgrsoft.cajondesastre.model1;

public class Boligrafo {

	String color;
	String tipo;
	String material;
	double peso;
	double altura = 5.7;
	boolean controlAprobado = false;
		
}
