package com.pgrsoft.cajondesastre.model1;

public class Perro {

	String nombre;
	String raza;
	Collar collar;     // relaci�n HAS-A
}
