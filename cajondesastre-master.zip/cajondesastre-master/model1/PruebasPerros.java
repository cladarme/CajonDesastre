package com.pgrsoft.cajondesastre.model1;

public class PruebasPerros {

	public static void main(String[] args) {
		
		Collar c1 = new Collar();
		Collar c2 = new Collar();
		Collar c3 = c2;
		
		Perro p1 = new Perro();
		Perro p2 = new Perro();
		
		p1.collar = c1;
		p2.collar = c2;
		
		p1 = p2;
		p1.collar = null;
		
		c1 = null;
		
		// c1.material = "cuero";	// esto provoca NullPointerException
		
		c2 = c1;
		
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);

	}

}
