package com.pgrsoft.cajondesastre.model1;

public class Collar {

	String material;
	boolean pinchos;
	
}
