package com.pgrsoft.cajondesastre.model1;

public class BolaNavidad {

	// variables de instancia
	// properties
	// atributos
	// campos/fields
	
	int codigo;
	String color;
	String material;
	double diametro;
	double precioCoste;
	double preciVenta;
	String nombre;
	
	
	
	
}
