package com.pgrsoft.cajondesastre.model1;

public class Coche {

	double precio;
	String marca;
	String color;
	String modelo;
	String carburante;
	int kilometros;
	int a�o;
	boolean siniestrado;
	char certificadoEmisiones;
	
	
}
