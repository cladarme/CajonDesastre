package com.pgrsoft.cajondesastre.model1;

public class PruebasInstanciacion {

	public static void main(String[] args) {
		
		BolaNavidad bola1 = new BolaNavidad();
		BolaNavidad bola2 = new BolaNavidad();
		
		bola1.codigo = 1243355;
		bola1.color = "plateado";
		bola1.diametro = 3.2;
		bola1.material = "pl�stico";
		bola1.nombre = "purple ball";
		bola1.precioCoste = 0.02;
		bola1.preciVenta = 12.50;
		
		bola2.codigo = 6735555;
		
		// Vamos a mostrar por la consola el valor de las variables
		
		System.out.println("c�digo de la bola1: " + bola1.codigo);
		System.out.println("c�digo de la bola2: " + bola2.codigo);
		
		
		
		

	}

}
