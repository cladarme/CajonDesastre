package com.pgrsoft.cajondesastre.model1;

public class Cliente {

	String CIF;
	String nombre;
	String direccion;
	String poblacion;
	String cPostal;
	String provincia;
	String pais;
	
	boolean gold;
	boolean moroso;
	
	
	
	
}
