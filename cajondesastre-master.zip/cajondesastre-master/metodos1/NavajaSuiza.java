package com.pgrsoft.cajondesastre.metodos1;

public class NavajaSuiza{

	public void cortar() {
		System.out.println("navaja suiza cortando...");
	}
	
	public void descorchar() {
		if (Math.random() < 0.5) {
			System.out.println("corcho extraido...");
		} else {
			System.out.println("corcho roto dentro de la botella");
		}
	}
	
	public void atornillar(int numeroVueltas) {
		
		// Cuando numeroVueltas es negativo, estamos desatornillando
		
		if (numeroVueltas < 0 ) {
			System.out.println("desatornillando con " + numeroVueltas + " n�mero de vueltas");
		} else {
			System.out.println("atornillando con " + numeroVueltas + " n�mero de vueltas");
		}
	}
	
	public void cortarConTijera() {
		System.out.println("Navaja suiza cortando con tijera....");
	}

}
