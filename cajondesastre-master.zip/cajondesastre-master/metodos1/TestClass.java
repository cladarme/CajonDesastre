package com.pgrsoft.cajondesastre.metodos1;

public class TestClass {

	public static void main (String[] args) {
		
		// Aqu� es donde empieza el programa...
		
		
	//	   tipo       variable     forma de crear instancia   
		NavajaSuiza navajaSuiza = new NavajaSuiza();
		
		navajaSuiza.cortar();
		navajaSuiza.descorchar();
		navajaSuiza.atornillar(-7);
		
		
	}

}
