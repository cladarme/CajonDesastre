package com.pgrsoft.cajondesastre.model3;

import java.util.Date;

public class TestClass {

	public static void main(String[] args) {
		
		// 1.- Declaramos e instanciamos una multa
		
		Multa multa = new Multa();
		
		// 2.- Seteamos todos sus atributos
		
		multa.setCodigo(1332443);
		multa.setFecha(new Date());
		multa.setImporte(700.0);
		multa.setLongitud(-34.3556557);
		multa.setLatitud(3.46547765);
		multa.setMatricula("3445DKM");
		multa.setNombreInfractor("Pep�n G�lvez Ridruejo");
		multa.setNombreAgente("Honorio Mart�n Salvador");
		multa.setMotivo("Excede 3 minutos en zona azul el d�a de Navidad");
		
		// 3.- Mostramos por consola la "ficha" de la multa
		
		System.out.println(multa);
		
		
		
		

	}

}
