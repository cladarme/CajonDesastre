package com.pgrsoft.cajondesastre.model3;

import java.util.Date;

public class Multa {

	private int codigo;
	private String motivo;
	private String matricula;
	private String nombreInfractor;
	private String nombreAgente;
	private double longitud;
	private double latitud;
	private Date fecha;
	private double importe;
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public String getMotivo() {
		return motivo;
	}
	
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public String getNombreInfractor() {
		return nombreInfractor;
	}
	
	public void setNombreInfractor(String nombreInfractor) {
		this.nombreInfractor = nombreInfractor;
	}
	
	public String getNombreAgente() {
		return nombreAgente;
	}
	
	public void setNombreAgente(String nombreAgente) {
		this.nombreAgente = nombreAgente;
	}
	
	public double getLongitud() {
		return longitud;
	}
	
	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}
	
	public double getLatitud() {
		return latitud;
	}
	public void setLatitud(double latitud) {
		this.latitud = latitud;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public double getImporte() {
		return importe;
	}
	
	public void setImporte(double importe) {
		this.importe = importe;
	}

	@Override
	public String toString() {
		return "Multa [codigo=" + codigo + ", motivo=" + motivo + ", matricula=" + matricula + ", nombreInfractor="
				+ nombreInfractor + ", nombreAgente=" + nombreAgente + ", longitud=" + longitud + ", latitud=" + latitud
				+ ", fecha=" + fecha + ", importe=" + importe + "]";
	}
	
}
