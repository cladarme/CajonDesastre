package com.pgrsoft.cajondesastre.ejercicios3;

public class NumberFormatter {

	public String convert(int numero) {
		
		return null;
	}
	
}
