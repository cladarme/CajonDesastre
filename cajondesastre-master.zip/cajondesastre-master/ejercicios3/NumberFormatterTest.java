package com.pgrsoft.cajondesastre.ejercicios3;

public class NumberFormatterTest {

	public static void main(String[] args) {
			
	}
}
