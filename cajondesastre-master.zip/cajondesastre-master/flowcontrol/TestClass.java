package com.pgrsoft.cajondesastre.flowcontrol;

public class TestClass {

	public static void main(String[] args) {
		
		// if
		
		int nota = 4;
		
		if (nota >= 5) {
			System.out.println("aprobado");
		}
		
		if (nota >= 5) {
			System.out.println("aprobado");
		} else {
			System.out.println("suspendido");
		}
		
		// Operadores de comparaci�n...
		//
		// 	== 	igualdad
		// 	>  	mayor que
		// 	<  	menor que
		// 	>= 	mayor o igual que
		// 	<= 	menor o igual que
		// 	!= 	diferente a
		// 	!  	NOT(negador) Cambiar el valor booleano.
		// 	&& 	AND l�gico
		// 	|| 	OR l�gico
		
		// Mala pr�ctica con el if
		
		boolean descatalogado = true;
		
		if (descatalogado == true) {
			System.out.println("producto descatalogado...");
		}
		
		// Lo anterior se escribor�a as�...
		
			
		if (descatalogado) {
			System.out.println("producto descatalogado...");
		}
		
		// Curiosidad del if
		
		if(true) {
			System.out.println("condici�n es true...");
		}
		
		// Operador ternario
		int valor = 74;
		
		String resultado = null;
		
		if (valor >= 50) {
			resultado = "exito";
		} else {
			resultado = "fracaso";
		}
		
		System.out.println("Resultado: " + resultado);
		
		// La expresi�n anterior, con el operador ternario ser�a...
		
		resultado = valor >=50 ? "exito" : "fracaso";
		
		// while => Un bloque de c�digo se ejecutar� mientras se cumpla una condici�n
		
		// ejemplo de bucle infinito...
		//double peso = 94.5;
		//while(peso >= 90) {
		//	System.out.println("peso mayor que 90");
		//}
		
		int contador = 5;
		
		while (contador > 0) {
			System.out.println(contador);
			//contador = contador - 1; // OJO! No est� del todo bien...
			//contador -= 1;		   // mejor que lo anterior	
			contador--;                // la mejor manera de restar 1
		}
		
		// Variante del While => do While (el bloque se ejecuta como m�nimo una vez)
		
		int numero = 0;
		
		do {
			System.out.println(numero);
			numero++ ;
		} while(numero < 10);
		
		// for  => nos permite efectuar "n" iteraciones
		
		for (int i = 0; i < 10 ; i++) {
			System.out.println("i: " + i);
		}
		
		for(int i = 2; i <= 20; i += 2) {
			System.out.println("numero par: " + i);
		}
		
		for(int i = 20; i >= 0; i -=2 ) {
			System.out.println("numero par *: " + i);
		}
		
		// Ejercicio... tablas de multiplicar
		
		System.out.println("\n\n");
		
		for (int i = 0; i < 10; i++) {
			
			System.out.println("\nTabla del " + i);
			System.out.println("===============\n");
			
			for (int k = 0; k < 10; k++) {
				System.out.print(i + " x " + k + " = " + (i * k));
			}
		}
		
	}

}
