package com.pgrsoft.cajondesastre.survivalkit;

public class SurvivalKit {

	public static void main(String[] args) {
		convertionTest();
		stringTest();
	}

	public static void convertionTest() {

		// 1.- Convertir numero a String

		int numero = 100;

		String strNumero = null;

		// una manera poco ortodoxa ser�a lo siguiente....

		strNumero = "" + numero; // strNumero vale "100"

		// la manera correcta ser�a...

		strNumero = String.valueOf(numero);
		
		System.out.println("strNumero: " + strNumero);

		// 2.- Convertir un String a un n�mero o boolean

		String strNumeroProductos = "124335";
		String strSalario = "4570.0";
		String strActivo = "true";
		String strLiguesJulioIglesias = "1243356564454";

		int numeroProductos = Integer.parseInt(strNumeroProductos);
		double salario = Double.parseDouble(strSalario);
		boolean activo = Boolean.parseBoolean(strActivo);
		long liguesJulioIglesias = Long.parseLong(strLiguesJulioIglesias);

		System.out.println(numeroProductos);
		System.out.println(salario);
		System.out.println(activo);
		System.out.println(liguesJulioIglesias);
	}

	public static void stringTest() {

		// 1.- C�mo conocer el tama�o de un String

		String nombre = "Pep�n";
		int numeroCaracteres = nombre.length();

		System.out.println("Pep�n tiene " + numeroCaracteres + " caracteres.");

		// 2.- C�mo obtener un subtring a partir de un string

		// a) A partir de una posici�n dada, hasta el final

		String str1 = "tent�culo";
		String subcadena1 = str1.substring(2);

		System.out.println(subcadena1);

		// b) Desde una posici�n inicial a una final (-1)

		String str2 = "cualquiera";
		String subcadena2 = str2.substring(2, 6); // ojo! por la dercha es 1 menos!

		System.out.println(subcadena2);

		// 3.- Como convertir un String a may�scula o min�scula

		String str3 = "pep�n G�lvez RIDRUEJO";

		String strMayuscula = str3.toUpperCase();
		String strMinuscula = str3.toLowerCase();

		System.out.println(strMayuscula);
		System.out.println(strMinuscula);

		// 4.- Como quitar espacios en blanco a derecha e izquierda.

		String str4 = "         soy un texto       ";

		System.out.println("*" + str4 + "*");

		String strTextoSinEspacios = str4.trim();

		System.out.println("*" + strTextoSinEspacios + "*");

		// 5.- C�mo obtener el caracter de una determinada posici�n

		String str5 = "supercalifragilistico";

		char caracter = str5.charAt(4); // obtengo el caracter de la posici�n 4

		System.out.println("caracter en posici�n 4: " + caracter);

		// 6.- C�mo conocer la posici�n que ocupa un determinado caracter

		String str6 = "br�coli";

		// Qu� posici�n ocupa la "l"

		int posicion = str6.indexOf("l");

		System.out.println("Posici�n de la l: " + posicion);

		String str7 = "La casa de papel"; // aqu� me interesa la posici�n de la
										  // primera "p" a partir de la posici�n 12

		System.out.println(str7.indexOf("p", 12));

	}

}
