package com.pgrsoft.cajondesastre.model5;

public class Obra {
	
	private String ISBN;
	private String autor;
	private String titulo;
	private boolean aptoMenores;
	private double precio;
	
	public String getISBN() {
		return ISBN;
	}
	
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	
	public String getAutor() {
		return autor;
	}
	
	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	public boolean isAptoMenores() {
		return aptoMenores;
	}
	
	public void setAptoMenores(boolean aptoMenores) {
		this.aptoMenores = aptoMenores;
	}
	
	public double getPrecio() {
		return precio;
	}
	
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	

}
