package com.pgrsoft.cajondesastre.model5;

public class VideoJuego extends Obra {
	
	private String plataforma;

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}
	
	
}
