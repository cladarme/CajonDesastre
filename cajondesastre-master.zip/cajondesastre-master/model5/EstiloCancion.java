package com.pgrsoft.cajondesastre.model5;

public enum EstiloCancion {

	POP,ROCK,FUNK,JAZZ,SOUL;
}
