package com.pgrsoft.cajondesastre.model5;

public class TestClass {

	public static void main(String[] args) {
		
		Cancion c1 = new Cancion();
		
		c1.setTitulo("One Nation Under a Groove");
		c1.setAutor("George Clinton");
		c1.setEstilo(EstiloCancion.JAZZ);

	}

}
