package com.pgrsoft.cajondesastre.model5;

public class Cancion extends Obra{

	private int BPM;
	private int duracion; // en segundos
	private EstiloCancion estilo;
	public int getBPM() {
		return BPM;
	}
	public void setBPM(int bPM) {
		BPM = bPM;
	}
	public int getDuracion() {
		return duracion;
	}
	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	public EstiloCancion getEstilo() {
		return estilo;
	}
	public void setEstilo(EstiloCancion estilo) {
		this.estilo = estilo;
	}
	
	
	
	
}
