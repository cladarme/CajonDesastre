package com.pgrsoft.cajondesastre.model2;

import java.util.Date;

public class Persona {
	
	private Date fechaNacimiento;
	private String nombre;
	private String apellido1;
	private String apellido2;
	private double peso;
	private double altura;
	private String colorOjos;
	private String colorPelo;
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getApellido1() {
		return apellido1;
	}
	
	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}
	
	public String getApellido2() {
		return apellido2;
	}
	
	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}
	
	public double getPeso() {
		return peso;
	}
	
	public void setPeso(double peso) {
		this.peso = peso;
	}
	
	public double getAltura() {
		return altura;
	}
	
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	public String getColorOjos() {
		return colorOjos;
	}
	
	public void setColorOjos(String colorOjos) {
		this.colorOjos = colorOjos;
	}
	
	public String getColorPelo() {
		return colorPelo;
	}
	
	public void setColorPelo(String colorPelo) {
		this.colorPelo = colorPelo;
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", peso=" + peso
				+ ", altura=" + altura + ", colorOjos=" + colorOjos + ", colorPelo=" + colorPelo + "]";
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	

}
