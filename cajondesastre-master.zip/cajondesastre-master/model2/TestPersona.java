package com.pgrsoft.cajondesastre.model2;

import java.util.Date;

public class TestPersona {

	public static void main(String[] args) {
		
		Persona p1 = new Persona();
		
		
		p1.setPeso(-2343);
		
		double peso = p1.getPeso();
		
		System.out.println(peso);
		System.out.println(p1.getPeso());
		
		// Vamos a programar a otra persona...
		
		Persona p2 = new Persona();
		p2.setFechaNacimiento(new Date()); // la fecha de "ahora"
		p2.setAltura(1.85);
		p2.setPeso(95.7);
		p2.setColorOjos("negro");
		p2.setColorPelo("blanco");
		p2.setNombre("Pep�n");
		p2.setApellido1("G�lvez");
		p2.setApellido2("Ridruejo");

		
		
		
		System.out.println(p2);
		
	}

}
