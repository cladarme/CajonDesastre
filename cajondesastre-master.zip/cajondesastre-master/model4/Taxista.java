package com.pgrsoft.cajondesastre.model4;

public class Taxista extends Persona {

	private String licenciaTaxista;

	public String getLicenciaTaxista() {
		return licenciaTaxista;
	}

	public void setLicenciaTaxista(String licenciaTaxista) {
		this.licenciaTaxista = licenciaTaxista;
	}
	
}
