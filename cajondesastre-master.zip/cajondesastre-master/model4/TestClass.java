package com.pgrsoft.cajondesastre.model4;

public class TestClass {

	public static void main(String[] args) {
		
		Taxista taxista = new Taxista();
		Cliente cliente = new Cliente();
		
		taxista.setNombre("Pep�n");
		taxista.setApellido1("G�lvez");
		taxista.setApellido2("Ridruejo");
		
		cliente.setNombre("Honorio");
		
		// Estoy instanciando un Cliente y a un Taxista
		// Ambos los estoy "tratando" como personas.... 
		
		Persona p1 = new Cliente();
		Persona p2 = new Taxista();
		
		System.out.println(p1);
		System.out.println(p2);
		

	}

}
