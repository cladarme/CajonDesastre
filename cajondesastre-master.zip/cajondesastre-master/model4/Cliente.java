package com.pgrsoft.cajondesastre.model4;

public class Cliente extends Persona {
	
	private boolean tarjetaGold;

	public boolean isTarjetaGold() {
		return tarjetaGold;
	}

	public void setTarjetaGold(boolean tarjetaGold) {
		this.tarjetaGold = tarjetaGold;
	}
	
}
