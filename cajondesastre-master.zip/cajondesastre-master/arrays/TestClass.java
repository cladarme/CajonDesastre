package com.pgrsoft.cajondesastre.arrays;

import java.util.Arrays;

public class TestClass {

	public static void main(String[] args) {
		
		// 1.- Defino un array de int inicializado
		
		int[] numeros = {10,-6,50,0};
		
		// 2.- Defino un array de int sin inicializar
		
		int[] numeros2 = new int[4];  // 0,0,0,0
		
		// 3.- C�mo acceder a un elemento de un array...
		
		System.out.println(numeros[2]);
		
		// 4.- Como escribir un valor en un array...
		
		numeros[3] = 8;
		
		// 5.- Otras cosas que se pueden hacer...
		
		numeros2[1] = numeros[2];
		
		// 6.- Forma de conocer el tama�o de un array...
		
		System.out.println("numeros tiene " + numeros.length + " elementos.");
		
		// 7.- Forma de imprimir los valores de un array "de un plumazo"
		
		System.out.println(numeros); // ESTO NO FUNCIONA!
		System.out.println(Arrays.toString(numeros)); // ESTO S� FUNCIONA!
		System.out.println(Arrays.toString(numeros2));
		
		String[] nombres = {"Pep�n","Anna","Honorio","Carlota"};
		
		System.out.println(Arrays.toString(nombres));
		
		// 8.- Forma "cl�sica" de iterar un array. Utilizamos el �ndice...
		
		for( int i = 0; i < nombres.length; i++) {
			System.out.println(i + ": " + nombres[i]);
		}
		
		for(int i = nombres.length -1; i >= 0; i--) {
			System.out.println(i + ": " + nombres[i]);
		}
		
		// 9.- Forma c�moda de iterar un array (cuando los �ndicies no nos importan)
		
		// Iteraci�n con "for each"
		
		
		for(String nombre : nombres) {
			System.out.println("===> " +  nombre);
		}
		
		// System.out.println("Qu� me devuelve? : " + nombres[4]); // Ojo! lanza excepci�n
		
	}

}
