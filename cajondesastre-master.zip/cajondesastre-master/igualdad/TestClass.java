package com.pgrsoft.cajondesastre.igualdad;

public class TestClass {

	public static void main(String[] xxxxxx) {
		
		int a = 1;
		int b = 5;
		
		double c = 57.2;
		double d = 5.000000;
		
		char e = 'A';
		char f = 'a';
		
		boolean g = true;
		boolean h = false;
		
		String i = "pepin";
		String j = "pepin";
		
		// NUNCA JAM�S COMPAREIS STRINGS DE ESTA FORMA!!!!!!!!!!!
		// NO!!!!!
		
		if (i == j) {
			System.out.println("son iguales");
		} else {
			System.out.println("son diferentes");
		}
		
		// ESTA ES LA MANERA CORRECTA DE COMPARAR STRINGS
		// NO SOLO STRINGS, TAMBI�N CUALQUIER OBJETO DE CUALQUIER CLASE
		
		if (i.equals(j)) {
			System.out.println("son iguales");
		} else {
			System.out.println("son diferentes");
		}
		
		
		
		
		if (a == b) {};
		
		if (b == d) {
			System.out.println("resulta que b == d");
			
		if (e == f) {
			System.out.println("e == f");
		}
		
		
		
		
		
		
	};
		
		
		
		
	}

}
