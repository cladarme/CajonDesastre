package com.pgrsoft.cajondesastre.ejercicios;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		String texto = "Are you talking to me?";
		
		// Vamos a iterar todos los caracteres del string y los vamos a
		// imprimir uno a uno...
		
		// Indicaciones
		// 1.- Necesitamos una variable int que contenga el tama�o del String
		// 2.- for donde el �ndice ir� desde 0 hasta el tama�o
		// 3.- Dentro del for utilizaremos charAt() para extraer el caracter
		
		int longitud = texto.length();
		
		for (int i = 0; i < longitud; i++) {
			char caracter = texto.charAt(i);
			System.out.println(caracter);
		}
		
	}

}
