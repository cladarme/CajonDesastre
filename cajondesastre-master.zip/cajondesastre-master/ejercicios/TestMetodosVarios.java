package com.pgrsoft.cajondesastre.ejercicios;

public class TestMetodosVarios {

	public static void main(String[] args) {
		
		MetodosVarios metodosVarios = new MetodosVarios();
		
		// Prueba 1
		
		String nombreCompleto = metodosVarios.getNombreCompleto("Pep�n", "G�lvez", "Ridruejo");
		System.out.println("1.- nombre completo: " + nombreCompleto);
		
		// Prueba 2
		
		String[] nombres = {"Pep�n", "Anna", "Carlota", "Honorio", "Max", "Pep", "Leonarda"};
		int numeroNombresLargos = metodosVarios.getNumeroNombresLargos(nombres);
		System.out.println("2.- n�mero de nombres largos: " + numeroNombresLargos);
		
		
		// Prueba 3
		
		double[] numeros = {10.0, -20.0, 5.0, -500.0};
		
		double resultado1 = metodosVarios.getSumaNumeros(numeros);
		System.out.println("3.- Suma de n�meros: " + resultado1);
		
		
		// Prueba 4
		
		double resultado2 = metodosVarios.getSumaNumerosPositivos(numeros);
		System.out.println("4.- Suma de n�meros: " + resultado2);

		// Prueba 5
		
		String textoCambiado = metodosVarios.getStringCambiado("esto es muy divertido", 'i');
		System.out.println("5.- Texto cambiado: " + textoCambiado);
		
		// Prueba 6
		
		String textoRevertido = metodosVarios.reverse("visto");
		System.out.println("6.- texto revertido: " + textoRevertido);
		
		// Prueba 7
		
		double descuento1 = metodosVarios.getDescuento(30.0, "hardware", 20, false);
		System.out.println("7.- descuento: " + descuento1);

		// Prueba 8
		
		double[] importes = {1,1,1,1,1};
		double descuento2 = metodosVarios.getDescuento(importes);
		System.out.println("8.- descuento: " + descuento2);
		
		// Prueba 9
		
		String[] strImportes = {"2.34", "1.25", "6.3", "9.7"};
		double descuento3 = metodosVarios.getDescuento(strImportes);
		System.out.println("9.- descuento: " + descuento3);
		
		// Prueba 10
		
		String rima = metodosVarios.getRima(3);
		System.out.println("10.- Rima: " + rima);
		
	}

}
