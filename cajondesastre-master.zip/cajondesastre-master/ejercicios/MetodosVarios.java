package com.pgrsoft.cajondesastre.ejercicios;

public class MetodosVarios {

	public String getNombreCompleto(String nombre, String apellido1, String apellido2) {

		return apellido1 + " " + apellido2 + ", " + nombre;
	}

	// 2
	
	// Se consideran nombres largos aquellos que tienen m�s de 3 caracteres
	public int getNumeroNombresLargos(String[] nombres) {
		
		int numeroNombresLargos = 0;
		
		for(String nombre :nombres) {
			if (nombre.length() > 3) {
				numeroNombresLargos++;
			}
		}
		
		return numeroNombresLargos;
	}
	
	// 3
	
	public double getSumaNumeros(double[] numeros) {
		
		double resultado = 0.0;
		
		for(double numero:numeros) {
			resultado += numero;
		}
		
		return resultado;
	}
	
	// 4
	
	// Igual que el ej. 3, pero s�lo se tienen en cuenta los n�meros positivos
	public double getSumaNumerosPositivos(double[] numeros) {
		
		double resultado = 0.0;
		
		for(double numero:numeros) {
			if (numero > 0) {
				resultado += numero;
			}
		}
		
		return resultado;
	}
	
	
	// 5
	
	// Devuelve el texto con todas sus vocales cambiadas, seg�n la vocal
	// que llega como par�metro.
	// Por ejemplo, si texto = "Hola Mundo" y vocal = 'u'
	//              el m�todo devolver�a "Hulu Mundu"
	public String getStringCambiado(String texto, char vocal) {
		
		String respuesta = "";
		
		for(int i = 0; i < texto.length(); i++) {
			
			char caracter = texto.charAt(i);
			
			if(caracter == 'a' || 
			   caracter == 'e' || 
			   caracter == 'i' || 
			   caracter == 'o' || 
			   caracter == 'u') {
				
			   caracter = vocal;
			}
			
			respuesta += caracter;
			
		}
		
		return respuesta;
	}
	
	// 6
	
	// Devuelve el texto al rev�s
	
	public String reverse(String texto) {
		
		String respuesta = "";
		
		for(int i = texto.length() - 1; i >= 0 ; i--) {
			respuesta += texto.charAt(i);
		}
		
		return respuesta;
	}
	
	// 7
	
	// Este es un ejemplo t�pico de m�todo de negocio (business logic)
	// La l�gica es la siguiente...
	// Se aplica descuento para cualquier producto descatalogado (independientemente de todo)
	// En cado de aplicarse descuento, este es del 10%
	// Si el importe es superior a 100.0 se aplica descuento
	// Si el numeroItems es mayor que 5, se aplica descuento, siempre que el importe sea mayor que 75.0
	// Si la familia es "consumible" no se aplicar� descuento (a no ser que el producto est� descatalogado)
	
	public double getDescuento(double importe, String familia, int numeroItems, boolean descatalogado) {
		
		if (descatalogado) {
			return importe * 0.1;
		}
		
		boolean cumplePrecio = importe > 100 || (importe > 75.0 && numeroItems > 5);
		
		if (cumplePrecio && !familia.equals("consumible")) {
			return importe * 0.1;
		} 
		
		return 0.0;
	}
	
	// 8
	
	// Otro m�todo con "business logic", m�s sencillo que el anterior
	// Se suman todos los importes.
	// Si la suma total es mayor que 100.0 o el n�mero de productos > 5 aplica el 10% de descuento
	
	public double getDescuento(double[] importes) {
		
		double total = 0.0;
		
		for(double importe :importes) {
			total += importe;
		}
		
		if (total > 100 || importes.length > 5) {
			return total * 0.1;
		}
		
		return 0.0;
	}
	
	// 9
	
	// Lo mismo que en el ejercicio 8. La �nica diferencia es que los importes entran como String.
	public double getDescuento(String[] importes) {
		
		int numeroImportes = importes.length;
		double[] importesAsDouble = new double[numeroImportes];
		
		for(int i = 0; i < numeroImportes; i++) {
			importesAsDouble[i] = Double.parseDouble(importes[i]);   
		}
		
		return getDescuento(importesAsDouble);
	}
	
	// 10
	
	// Llega un n�mero (entre 1 y 9) el m�todo devuelve una frase que rima.
	// Por ejemplo, si entra 9, el m�todo podr�a devolver "vete a casa que llueve"
	//              si entra 4, el m�todo podr�a devolver "espera un rato"
	public String getRima(int cifra) {
		
		String[] rimas = {"Me gusta Unamuno",			// 0
						  "Me gusta P�rez Gald�s",		// 1
						  "Tengo mucho estr�s",
						  "Dejame un rato",
						  "Damos todos un brinco",
						  "No me mireis",
						  "Lanza un cohete",
						  "C�mete un bizcocho",
						  "Ma�ana llueve"};				// 8
		
		return rimas[cifra - 1];
	}
	
	

}
